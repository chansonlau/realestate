class Chainb < ActiveRecord::Base
  belongs_to :chaina
end