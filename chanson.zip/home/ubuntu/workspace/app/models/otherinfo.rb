class Otherinfo < ActiveRecord::Base
  belongs_to :place
end