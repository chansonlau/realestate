class Chainc < ActiveRecord::Base
  belongs_to :chainb
end