class Chaina < ActiveRecord::Base
end