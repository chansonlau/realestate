module PaypalsHelper
end
